"""
Nasledujuci program sluzi ku spusteniu a otestovaniu behu systemu

Nemodifikujte okrem casu behu systemu
"""

import task2_2 as system
import binary2_2 as systems
import threading
import random
import time

"""
baliaci system
"""
sys = system.System()

"""
Viac vlaknovo spusti system
"""
def StartSystem():
    sys_thread = threading.Thread(target=sys.Start())
    sys_thread.daemon = True
    sys_thread.start()
    
    container_thread = threading.Thread(target=sys.RunContainerSystem())
    container_thread.daemon = True
    container_thread.start()

"""
Zahaji zastavenie systemu
"""
def StopSystem():
    sys.Stop()

"""
Zisti stav systemu po zastaveni
"""
def CheckSystem():
    while(sys.transfer.t.isAlive()): continue
    print('Kontejneru na konci: ' + str(len(sys.containers.conts)))
    print('Zabalenych darcekov: ' + str(sys.packer.gen))
    print('Prenesenych darcekov cez system: ' + str(sys.transfer.proc))
    if ( sys.packer.gen != sys.transfer.proc):
        print("V SYSTEME ZOSTALI DARCEKY!")
    if(sys.transfer.CheckBrokenPresents()):
        print("BOLI TRANSPORTOVANE ZLE ZABALENE DARCEKY!")
    
"""
Spusti beh systemu na 1 sekundu
"""
def RunSystem():
    run_thread = threading.Thread(target=StartSystem)
    run_thread.daemon = True
    run_thread.start()
    
    time.sleep(5) #cas behu systemu

    StopSystem()
    CheckSystem()

RunSystem()




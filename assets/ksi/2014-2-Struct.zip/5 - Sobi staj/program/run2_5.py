#!/usr/bin/env python2.7
# -*- coding: utf-8 -*-
from binary2_5 import EventLoop
from task2_5 import KsantuvStajovyZaznamenavac

if __name__ == '__main__':
    e = EventLoop()
    l = KsantuvStajovyZaznamenavac()
    for event in e.run():
        l.proved(event)

    raw_input('Program ukoncite stiskem klavesy...')

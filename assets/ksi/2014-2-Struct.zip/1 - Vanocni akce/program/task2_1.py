"""
V tomto priklade mate za ulohu naimplementovat funkciu FindOdd, ktora dostane v argumentoch zoznam celych cisel a ma vratit jedno lubovolne cislo - cislo ktore sa tam nachadza neparny pocet krat
"""



def FindOdd(numbers):

    hashmap = dict()
    for num in numbers:
      if num in hashmap:
        del hashmap[num]
      else:
        hashmap[num] = 1

    return hashmap.keys()[0]




import sys
import binary
# -*- coding: utf-8 -*-


def RunFunction():
    fail=0
    for i in range(300):
        fail+=binary.test0()
    print "1. Sada otestovana"
    for i in range(300):
        fail+=binary.test1()
    print "2. Sada otestovana"
    for i in range(300):
        fail+=binary.test2()
    print "3. Sada otestovana"
    for i in range(300):
        fail+=binary.test3()
    print "4. Sada otestovana"
    for i in range(300):
        fail+=binary.test4()
    print "5. Sada otestovana"
    
    if fail>0:
        print "Tvoj vysledok je zly na ",fail," vstupoch"
    else:
        print "Tvoj vysledok je spravny na vsetkych vstupoch"


RunFunction()
